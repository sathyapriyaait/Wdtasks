function calculateAge{
var current_year=parseInt(prompt("Enter your current year"));
    var birth_year=parseInt(prompt("Enter your birth year"));
    var cal_age=current_year-birth_year;
    alert("your age becomes"+cal_age+"or"+(cal_age+1));
    document.write(cal_age);
}
